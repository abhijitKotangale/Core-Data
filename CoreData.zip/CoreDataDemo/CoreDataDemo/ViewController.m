//
//  ViewController.m
//  CoreDataDemo
//
//  Created by Student P_07 on 11/04/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import "ViewController1.h"

@interface ViewController (){
    NSManagedObjectContext *context ;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    context = delegate.persistentContainer.viewContext;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)alert :(NSString *)msg{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Sign In" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"Sign In" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}


- (IBAction)listAction:(id)sender {
    //To Fetch Data
    
    [self performSegueWithIdentifier:@"ListButtonSegue" sender:self];
    
    
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"ListButtonSegue"]) {
        ViewController1 *obj=[segue destinationViewController];
        NSFetchRequest *fetchrequest =[NSFetchRequest fetchRequestWithEntityName:@"Student"];
        NSArray *arr =[context executeFetchRequest:fetchrequest error:nil];
        NSLog(@"%lu",(unsigned long)arr.count);
        NSLog(@"%@",arr);
        obj.arrlist=arr;
        
    }
}

- (IBAction)saveAction:(id)sender {
    
    if ([_idOutlet.text isEqualToString:@""]) {
        [self alert:@"Enter id"];
       
        
    }else if ([_nameOutlet.text isEqualToString:@""]){
        [self alert:@"Enter name"];
        
    }else if ([_AddressOutlet.text isEqualToString:@""]){
        [self alert:@"Enter address"];
    }else{
        NSEntityDescription  *entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:context];
        NSManagedObject *Manageobj = [[NSManagedObject alloc]initWithEntity:entity insertIntoManagedObjectContext:context];
        double studentid = [_idOutlet.text doubleValue];
        [Manageobj setValue:[NSNumber numberWithDouble:studentid] forKey:@"id"];
        [Manageobj setValue:_nameOutlet.text forKey:@"name"];
        [Manageobj setValue:_AddressOutlet.text forKey:@"address"];
        NSError *error;
        [context save:&error];
        if (error != nil) {
            [self alert:error.localizedDescription];
        }
        
        
        _idOutlet.text=@"";
        _nameOutlet.text=@"";
        _AddressOutlet.text=@"";
    }
    
}
@end
