//
//  ViewController.h
//  CoreDataDemo
//
//  Created by Student P_07 on 11/04/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)listAction:(id)sender;
- (IBAction)saveAction:(id)sender;

@property (strong, nonatomic) IBOutlet UITextField *idOutlet;
@property (strong, nonatomic) IBOutlet UITextField *nameOutlet;
@property (strong, nonatomic) IBOutlet UITextField *AddressOutlet;

@end

