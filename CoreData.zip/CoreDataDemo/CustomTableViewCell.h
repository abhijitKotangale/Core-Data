//
//  CustomTableViewCell.h
//  CoreDataDemo
//
//  Created by Student P_07 on 11/04/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *customIDOutlet;
@property (strong, nonatomic) IBOutlet UILabel *customNameOutlet;
@property (strong, nonatomic) IBOutlet UILabel *customAddressOutlet;

@end
