//
//  ViewController1.m
//  CoreDataDemo
//
//  Created by Student P_07 on 11/04/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import "ViewController1.h"
#import "CustomTableViewCell.h"
#import "ViewController.h"
#import "AppDelegate.h"
#import "ViewController2.h"
@interface ViewController1 (){
    NSIndexPath *index;
}

@end

@implementation ViewController1

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _arrlist.count;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CustomTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell==nil) {
        cell=[[CustomTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
   
    NSManagedObject *managedObject=[_arrlist objectAtIndex:indexPath.row];
    cell.customIDOutlet.text=[NSString stringWithFormat:@"%@",[managedObject valueForKey:@"id"]];
    cell.customNameOutlet.text=[managedObject valueForKey:@"name"];
    cell.customAddressOutlet.text=[managedObject valueForKey:@"address"];
    
    /*NSLog(@"%@",[managedObject valueForKey:@"id"]);
    NSLog(@"%@",[managedObject valueForKey:@"name"]);
    NSLog(@"%@",[managedObject valueForKey:@"address"]);*/
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    index=indexPath;
    [self performSegueWithIdentifier:@"2vcto1VC" sender:self];
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"2vcto1VC"]) {
        ViewController2 *obj=[segue destinationViewController];
        obj.object=(NSManagedObject *)[_arrlist objectAtIndex:index.row];
        obj.strID=[NSString stringWithFormat:@"%@",[obj.object valueForKey:@"id"]];
        obj.strName=[obj.object valueForKey:@"name"];
        obj.strAdd=[obj.object valueForKey:@"address"];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)UpdateAction:(id)sender {
}
@end
