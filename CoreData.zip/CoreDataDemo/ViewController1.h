//
//  ViewController1.h
//  CoreDataDemo
//
//  Created by Student P_07 on 11/04/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController1 : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *TableView;
@property (nonatomic,strong) NSArray *arrlist;


@end
