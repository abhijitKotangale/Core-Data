//
//  ViewController2.h
//  CoreDataDemo
//
//  Created by Student P_07 on 13/04/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface ViewController2 : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *txtID;
@property (strong, nonatomic) IBOutlet UITextField *txtName;
@property (strong, nonatomic) IBOutlet UITextField *txtAddress;
@property (strong, nonatomic) NSManagedObject *object;
@property (strong, nonatomic) NSString *strID;
@property (strong, nonatomic) NSString *strName;
@property (strong, nonatomic) NSString *strAdd;
- (IBAction)btnUpdate:(id)sender;

@end
