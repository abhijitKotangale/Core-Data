//
//  ViewController2.m
//  CoreDataDemo
//
//  Created by Student P_07 on 13/04/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import "ViewController2.h"

@interface ViewController2 (){
    NSManagedObjectContext *context;
    
}

@end

@implementation ViewController2

- (void)viewDidLoad {
    [super viewDidLoad];
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    context = delegate.persistentContainer.viewContext;

    _txtID.text=_strID;
    _txtName.text=_strName;
    _txtAddress.text=_strAdd;
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)alert :(NSString *)msg{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Sign In" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"Sign In" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}

- (IBAction)btnUpdate:(id)sender {
    if ([_txtID.text isEqualToString:@""]) {
        [self alert:@"Enter id"];
        
        
    }else if ([_txtName.text isEqualToString:@""]){
        [self alert:@"Enter name"];
        
    }else if ([_txtAddress.text isEqualToString:@""]){
        [self alert:@"Enter address"];
    }else{
      //  NSEntityDescription  *entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:context];
      //  NSManagedObject *Manageobj = [[NSManagedObject alloc]initWithEntity:entity insertIntoManagedObjectContext:context];
        double studentid = [_txtID.text doubleValue];
        [_object setValue:[NSNumber numberWithDouble:studentid] forKey:@"id"];
        [_object setValue:_txtName.text forKey:@"name"];
        [_object setValue:_txtAddress.text forKey:@"address"];
        NSError *error;
        [context save:&error];
        if (error != nil) {
            [self alert:error.localizedDescription];
        }
    }
}
@end
